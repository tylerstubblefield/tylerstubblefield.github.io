import matplotlib.pyplot as plt
import os.path
import numpy as np
import PIL
import PIL.ImageDraw as draw

#This opens the necessary file(s) and delegates the filepath
def openFile(filename, isPlt = True):
    # Go to the directory
    directory = os.path.dirname(os.path.abspath(__file__))
    # Get the path to the file
    filepath = os.path.join(directory, filename)
    # Open the image
    if isPlt:
        img = plt.imread(filepath)
    else:
        img = PIL.Image.open(filepath)
    return img

#This function allows us to add a shadow aspect to our image, which facilitates it's displaying of theme
def handShadows(img, fig, ax):
# Get Height and Width of image
    height = len(img)
    width = len(img[0])
    for r in range(350):
        for c in range(width):
            if sum(img[r][c])>500: # brightness R+G+B goes up to 3*255=765
                img[r][c]=[30,25,25,255] # R + B = magenta
    fig.canvas.draw

#This function adds the gothic effect to help convey the theme a bit more clearly
def gothicSky(img, fig, ax):
# Get Height and Width of image
    height = len(img)
    width = len(img[0])
    for r in range(350):
        for c in range(width):
            if sum(img[r][c])<400: # brightness R+G+B goes up to 3*255=765
                img[r][c]=[139,0,0,255] # R + B = magenta
    fig.canvas.draw

#Begins the process by just opening up the initial hands
hands = openFile('Images/hands.jpg')
# Original image
fig1, ax1 = plt.subplots(1,1)
ax1.axis('off')
ax1.imshow(hands, interpolation='none')

#Change the color of the sky to crimson
hands = openFile('Images/hands.jpg')
# Original image
fig2, ax2 = plt.subplots(1,1)
ax2.axis('off')
gothicSky(hands, fig2, ax2)
ax2.imshow(hands, interpolation='none')

# Image with new shadows on the arms
shadowArms = openFile('Images/hands.jpg')
fig3, ax3 = plt.subplots(1,1)
ax3.axis('off')
gothicSky(shadowArms, fig2, ax2)
handShadows(shadowArms, fig3, ax3)
ax3.imshow(shadowArms, interpolation='none')

# Shadow arms with sun
fig4, ax4 = plt.subplots(1,1)
ax4.axis('off')
sun = openFile('Images/sun.png', False)
pilshadowArms = PIL.Image.fromarray(shadowArms)
pilshadowArms.paste(sun, (-260,-100), mask=sun) 
ax4.imshow(pilshadowArms, interpolation='none')

# Shadow arms with sun + Introduction of new image(person on a boat)
fig5, ax5 = plt.subplots(1,1)
ax5.axis('on')
Drugs = openFile('Images/drugs.png', False)
#drugs image is Drugs
combinedDrugs = PIL.Image.fromarray(shadowArms)
combinedDrugs.paste(Drugs, (0,10), mask=Drugs) 
combinedDrugs.paste(sun, (-260,-100), mask=sun)
ax5.imshow(combinedDrugs, interpolation='none')

# Shadow arms with sun + Introduction of new image(person on a boat)
fig6, ax6 = plt.subplots(1,1)
ax6.axis('on')
x = openFile('Images/cross.png', False)
combinedDrugs = PIL.Image.fromarray(shadowArms)
combinedDrugs.paste(Drugs, (0,10), mask=Drugs) 
combinedDrugs.paste(x, (-190,-120), mask=x)
combinedDrugs.paste(sun, (-260,-100), mask=sun)
ax6.imshow(combinedDrugs, interpolation='none')

#Displays all the necessary images in order of process
fig6.show()
fig5.show()
fig4.show()
fig3.show()
fig2.show()
fig1.show()